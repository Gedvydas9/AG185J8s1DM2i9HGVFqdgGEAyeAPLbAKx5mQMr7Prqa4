﻿namespace TweaksAndThings.Enums;

public enum MrocHelperType
{
    Handbrake,
    GladhandAndAnglecock
}
